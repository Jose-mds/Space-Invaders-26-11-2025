import pygame

# define a Block class for individual barrier blocks
class Block(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((5, 5)) # each block is a 5×5 red square
        self.image.fill((0, 255, 0))  # green color
        self.rect = self.image.get_rect(topleft=(x, y))


# shape of the barrier using characters:
# 'x' = draw a block
# ' ' = empty space
shape = [
"  xxxxxxx  ",
" xxxxxxxxx ",
"xxxxxxxxxxx",
"xxxxxxxxxxx",
"xxxxxxxxxxx",
"xxx     xxx",
"xx       xx"
]

def make_barriers():
    barriers = pygame.sprite.Group()
    barrier_x_positions = [60, 180, 300, 420]   # horizontal positions of the 4 barriers
    barrier_y = 450      # all barriers appear at this vertical level

    # build each barrier out of blocks
    for bx in barrier_x_positions:
        for row_index, row in enumerate(shape):
            for col_index, char in enumerate(row):
                if char == "x":
                    # construct block at the correct position
                    x = bx + col_index * 5
                    y = barrier_y + row_index * 5
                    block = Block(x, y)
                    barriers.add(block)

    return barriers
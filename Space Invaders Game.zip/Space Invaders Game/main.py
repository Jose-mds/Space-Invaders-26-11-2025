import pygame
import random
import sys
from barriers import make_barriers

pygame.init()

# settings
WIDTH, HEIGHT = 550, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
pygame.display.set_caption("Space Invaders")

FPS = 60
ALIEN_FALL_LIMIT = 430

# sounds
def load_sound(path, volume=0.3):
    try:
        sound = pygame.mixer.Sound(path)
        sound.set_volume(volume)
        return sound
    except:
        print(f"Warning, unable to load, {path}")
        return None

# load the sound effects
laser_sound = load_sound("sounds/laser.wav")
hit_sound = load_sound("sounds/hit.mp3")
gameover_sound = load_sound("sounds/gameover.mp3", 0.2)
try:
    pygame.mixer.music.load("sounds/bgmusic.mp3")
    pygame.mixer.music.set_volume(0.05)
    pygame.mixer.music.play(-1)
except:
    pass


# load player image
try:
    player_img = pygame.image.load("images/defender.png").convert_alpha()
    player_img = pygame.transform.scale(player_img, (50, 30))
except:
    player_img = pygame.Surface((50, 30))
    player_img.fill((0, 200, 200))

player_x = WIDTH // 2
player_y = HEIGHT - 80
player_speed = 7
player_width, player_height = 50, 30

player_bullets = []
player_bullet_speed = -7

lives = 3
respawn_timer = 0  # frames until player can respawn

# load alien images
alien_imgs = []
for i in range(1, 4):
    try:
        img = pygame.image.load(f"images/invader{i}.png").convert_alpha()
        img = pygame.transform.scale(img, (40, 30))
    except:
        img = pygame.Surface((40, 30))
        img.fill((200, 100 + i * 30, 100))
    alien_imgs.append(img)

# create aliens
def create_aliens():
    aliens = []
    start_x = 80
    start_y = 80
    spacing_x = 70
    spacing_y = 60

    for col in range(6):
        for row in range(3):
            img = alien_imgs[row]
            rect = img.get_rect(topleft=(
                start_x + col * spacing_x,
                start_y + row * spacing_y
            ))
            aliens.append({"img": img, "rect": rect})
    return aliens

aliens = create_aliens()
alien_direction = 1
alien_speed = 4
alien_speed_increase = 0.25 # how much faster aliens get when one allien is destroyed
alien_drop = 20
alien_move_timer = 0
alien_move_delay = 12

alien_bullets = []
alien_bullet_speed = 5

barriers = make_barriers()

# explosion effects
explosions = []

# text rendering
font = pygame.font.SysFont(None, 32)
def draw_text(msg, x, y):
    screen.blit(font.render(msg, True, (255, 255, 255)), (x, y))


# reset game state
def reset_game():
    global player_x, lives, respawn_timer
    global player_bullets, alien_bullets, explosions, barriers
    global aliens, alien_direction, alien_speed, alien_move_delay

    player_x = WIDTH // 2
    lives = 3
    respawn_timer = 0

    player_bullets = []
    alien_bullets = []
    explosions = []

    barriers = make_barriers()

    aliens = create_aliens()
    alien_direction = 1
    alien_speed = 4
    alien_speed_increase = 0.25
    alien_move_delay = 12


# udate and draw explosions
def update_explosions():
    for e in explosions[:]:
        e["r"] += 2
        e["life"] -= 1
        if e["life"] <= 0:
            explosions.remove(e)

def draw_explosions():
    for e in explosions:
        pygame.draw.circle(screen, (255, max(0, 255 - e["r"] * 5), 0),
                           (e["x"], e["y"]), e["r"])


# main game loop
running = True
while running:
    screen.fill((0, 0, 0))

    # event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        # player shooting
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and respawn_timer == 0:
                bullet = pygame.Rect(player_x + player_width // 2 - 2,
                                     player_y, 4, 12)
                player_bullets.append(bullet)
                if laser_sound: laser_sound.play()

    # player movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player_x -= player_speed
    if keys[pygame.K_RIGHT]:
        player_x += player_speed

    player_x = max(0, min(player_x, WIDTH - player_width))

    # update player bullets
    for b in player_bullets[:]:
        b.y += player_bullet_speed
        if b.y < 0:
            player_bullets.remove(b)
            continue

        # when bullet hits alien
        for alien in aliens[:]:
            if b.colliderect(alien["rect"]):
                explosions.append({
                    "x": alien["rect"].centerx,
                    "y": alien["rect"].centery,
                    "r": 2,
                    "life": 10
                })
                if hit_sound: hit_sound.play()
                aliens.remove(alien)
                player_bullets.remove(b)
                alien_speed += alien_speed_increase
                break

        # when bullet hits barrier
        for block in barriers:
            if b.colliderect(block.rect):
                barriers.remove(block)
                if b in player_bullets:
                    player_bullets.remove(b)
                break

    # alien movement
    alien_move_timer += 1
    if alien_move_timer >= alien_move_delay:
        alien_move_timer = 0

        # check when aliens hit edge
        hit_edge = any(
            alien["rect"].right > WIDTH - 10 and alien_direction == 1 or
            alien["rect"].left < 10 and alien_direction == -1
            for alien in aliens
        )

        if hit_edge:
            alien_direction *= -1
            for alien in aliens:
                alien["rect"].y += alien_drop
            alien_move_delay = max(4, alien_move_delay - 1)  # speed up
        else:
            for alien in aliens:
                alien["rect"].x += alien_direction * alien_speed # aliens move faster each time one dies

    # alien shooting
    lowest_in_column = {} # track lowest alien in each column
    for alien in aliens:
        col = alien["rect"].x // 60
        if col not in lowest_in_column or alien["rect"].y > lowest_in_column[col]["rect"].y:
            lowest_in_column[col] = alien

    for alien in lowest_in_column.values():
        if random.randint(1, 180) == 1:
            rect = alien["rect"]
            alien_bullets.append(
                pygame.Rect(rect.centerx - 2, rect.bottom, 4, 12)
            )

    # alien bullet updates
    player_rect = pygame.Rect(player_x, player_y, player_width, player_height)

    for b in alien_bullets[:]:
        b.y += alien_bullet_speed

        if b.y > HEIGHT:
            alien_bullets.remove(b)
            continue

        # when bullet hits barrier
        for block in barriers:
            if b.colliderect(block.rect):
                barriers.remove(block)
                alien_bullets.remove(b)
                break

        # when bullet hits player
        if respawn_timer == 0 and b.colliderect(player_rect):
            lives -= 1
            respawn_timer = 50
            alien_bullets.remove(b)
            if hit_sound: hit_sound.play()

    # respawn timer countdown
    if respawn_timer > 0:
        respawn_timer -= 1

    # player loses when aliens gets too low
    for alien in aliens:
        if alien["rect"].bottom >= ALIEN_FALL_LIMIT:
            lives = 0

    # game over and player loses when lives run out
    if lives <= 0:
        screen.fill((0, 0, 0))
        draw_text("GAME OVER", WIDTH // 2 - 80, HEIGHT // 2 - 40)
        draw_text("Press R to Restart", WIDTH // 2 - 110, HEIGHT // 2 + 10)

        if gameover_sound and not gameover_sound.get_num_channels():
            gameover_sound.play()

        if keys[pygame.K_r]:
            reset_game()

        pygame.display.update()
        clock.tick(FPS)
        continue

    # plaiyer wins if all aliens are destroyed
    if len(aliens) == 0:
        screen.fill((0, 0, 0))
        draw_text("YOU WIN!", WIDTH // 2 - 60, HEIGHT // 2 - 40)
        draw_text("Press R to Play Again", WIDTH // 2 - 120, HEIGHT // 2 + 10)

        if keys[pygame.K_r]:
            reset_game()

        pygame.display.update()
        clock.tick(FPS)
        continue

    # drawing everything
    if respawn_timer % 10 < 5:  # blink player when respawning
        screen.blit(player_img, (player_x, player_y))

    for a in aliens:
        screen.blit(a["img"], a["rect"])

    for b in player_bullets:
        pygame.draw.rect(screen, (0, 255, 255), b)
    for b in alien_bullets:
        pygame.draw.rect(screen, (255, 255, 0), b)

    update_explosions()
    draw_explosions()

    barriers.draw(screen)

    draw_text(f"Lives: {lives}", 10, 10)

    pygame.display.update()
    clock.tick(FPS)
